<?php
$path = "./";
$page = "Home";
include $path."assets/inc/header.php";
?>
<div id="top" class="container">
    <main>
        <section id="intro">
            <h2>Welcome to UNIX/LINUX: ESSENTIAL GUIDE</h2>
            <p>This website is designed to provide beginners and intermediate users with the essential knowledge they
                need to get started with UNIX/LINUX.</p>
        </section>
        <section id="featured">
            <h2>Featured Content</h2>

        </section>
    </main>
</div>
<?php
include $path."assets/inc/footer.php";
?>