</section>
<footer>
    <div class="brdCrmbTrl">
        <a href="#">Home</a> >
        <a href="#">Somewhere</a> >
        <a href="#">Here</a>
    </div>
    <div class="logo footLog">&copy; Copyright 2023, (Dys)functional</div>
</footer>
</body>

</html>